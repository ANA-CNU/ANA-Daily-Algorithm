﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ConsoleAppTest
{
    public class Database
    {
        public readonly object lockObj = new();
        public readonly List<Data> db = new();
        public int LowerBound => db.First().Score;
        public int UpperBound => db.Last().Score;

        private readonly int dbSize;

        public Database(int dbSize)
        {
            this.dbSize = dbSize;

            if (!Directory.Exists("backup"))
                Directory.CreateDirectory("backup");
            foreach (var file in Directory.EnumerateFiles("backup").OrderByDescending(x => x))
            {
                Offer(Data.FromFile(file));
            }

            if (db.Count == 0)
            {
                for (int i = 0; i < 30; i++)
                {
                    Offer(Data.CreateRandom());
                }
            }
        }

        public void Offer(Data d)
        {

            if (d.Score == 0)
                throw new InvalidDataException();

            for (int i = 0; i < db.Count; i++)
            {
                if (db[i].Score == d.Score)
                {
                    d.Tries += db[i].Tries;
                    db[i] = d;
                    return;
                }
            }

            db.Add(d);
            db.Sort((x, y) => x.Score.CompareTo(y.Score));

            var rand = new Random();
            while (dbSize < db.Count)
                db.RemoveAt(rand.Next(0, db.Count >> 1));
        }

        public Data PickRandom()
        {
            int n = db.Count;
            Random random = new Random();
            int totalWeight = n * (n + 1) / 2;
            double randomValue = random.NextDouble() * totalWeight;
            double cumulativeWeight = 0.0;
            for (int i = 0; i < n; i++)
            {
                cumulativeWeight += i + 1;
                if (randomValue < cumulativeWeight)
                {
                    db[i].Tries++;
                    return db[i];
                }
            }

            // 여기에 도달하면 안 되지만, 안전을 위해 첫 번째 데이터를 반환합니다.
            return db[0];
        }

        public void ReplaceWith(int prevScore, Data newData)
        {
            db.RemoveAt(db.FindIndex(x => x.Score == prevScore));
            Offer(newData);
        }

        public void SaveState()
        {
            foreach (var file in Directory.EnumerateFiles("backup"))
            {
                File.Delete(file);
            }

            foreach (var data in db)
            {
                File.WriteAllText(Path.Combine("backup", $"{data.Score}.txt"), data.ToString());
            }
        }

    }
}
