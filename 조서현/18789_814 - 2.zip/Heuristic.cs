﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppTest
{
    internal static class Heuristic
    {
        private static List<int[]> Permutations = PermuationTool.GetPermutations(new[] { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 });
        private static readonly List<int>[] Numbers = new List<int>[12000];
        private static readonly (int, int)[] Moves = { (0, 1), (0, -1), (1, 0), (-1, 0), (1, 1), (1, -1), (-1, 1), (-1, -1) };

        static Heuristic()
        {
            for (int i = 1; i < 12000; i++)
            {
                Numbers[i] = new List<int>();
                Numbers[i].AddRange(i.ToString().Select(x => int.Parse(x.ToString())));
            }
        }

        public static Data Mutate(Data orig)
        {
            var rand = new Random();
            var method = rand.NextDouble();
            if (method < 0.3)
            {
                return MutateSwap(orig);
            }
            else
            {
                return MutateRandom(orig);
            }
        }

        private static Data MutateSwap(Data orig)
        {
            var rand = new Random();
            var res = orig.DeepCopy();
            int a = rand.Next(0, 8), b = rand.Next(0, 14), c = rand.Next(0, 8), d = rand.Next(0, 14), tmp;
            tmp = res.Table[a, b];
            res.Table[a, b] = res.Table[c, d];
            res.Table[c, d] = tmp;

            res.Score = Program.ScoreMetric(res);
            return res;
        }

        public static Data MutateRandom(Data orig)
        {
            var rand = new Random();
            var res = orig.DeepCopy();
            //var mutateCnt = rand.Next(1, 5);
            int curTries = Program.Tries - Program.LastBestTry;
            var mutateCnt = rand.Next(1, (curTries > 50000) ? Math.Min((int)MathF.Log((float)curTries) / 2, 25) : 3);
            for (int i = 0; i < mutateCnt; i++)
            {
                res.Table[rand.Next(0, 8), rand.Next(0, 14)] = rand.Next(0, 10);
            }

            res.Score = Program.ScoreMetric(res);
            return res;
        }

        public static Data MutatePermutation(Data orig)
        {
            var rand = new Random();
            var maxScore = 0;
            var res = orig.DeepCopy();
            var permutationCnt = rand.Next(1000, 10000);
            foreach (var p in Permutations.TakeRandom(permutationCnt))
            {
                var tmp = orig.DeepCopy();
                for (int i = 0; i < 8; i++)
                {
                    for (int j = 0; j < 14; j++)
                    {
                        tmp.Table[i, j] = p[tmp.Table[i, j]];
                    }
                }
                tmp.Score = Program.ScoreMetric(tmp);
                if (maxScore <= tmp.Score)
                {
                    res = tmp;
                    maxScore = tmp.Score;
                }
            }

            return res;
        }

        public static Data MutateRandomParallel(Data orig, int n)
        {
            Data[] results = new Data[n];
            Parallel.For(0, n, (i) =>
            {
                results[i] = MutateRandom(orig);
            });
            Data res = results[0];
            for (int i = 1; i < n; i++)
            {
                if (res.Score < results[i].Score)
                {
                    res = results[i];
                }
            }

            return res;
        }



        public static int ScoreMetric1(Data data)
        {
            //return ScoreMetric2(data);
            var table = data.Table;
            int i = 1;
            while (i < Numbers.Length)
            {
                if (!Readable(table, i))
                    return i;
                i++;
            }

            return i;
        }

        public static int ScoreMetric2(Data data)
        {
            var table = data.Table;
            int i = 1, ans = 0;
            while (i < Numbers.Length)
            {
                if (Readable(table, i))
                    ans++;
                i++;
            }

            return ans;
        }

        private static bool Readable(int[,] table, int cur)
        {
            var target = Numbers[cur];

            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 14; j++)
                {
                    if (target[0] != table[i, j]) continue;
                    if (target.Count == 1)
                        return true;

                    var stack = new Stack<(int, int, int)>();
                    stack.Push((i, j, 0));
                    while (stack.Count > 0)
                    {
                        var (x, y, cnt) = stack.Pop();
                        foreach (var (dx, dy) in Moves)
                        {
                            int nx = x + dx; int ny = y + dy;
                            if (nx is >= 0 and < 8 && ny is >= 0 and < 14 && target[cnt + 1] == table[nx, ny])
                            {
                                if (cnt + 2 == target.Count)
                                    return true;
                                stack.Push((nx, ny, cnt + 1));
                            }
                        }
                    }
                }
            }

            return false;
        }

        public static int NextExcept(this Random rand, int n)
        {
            var v = rand.Next(0, 10);
            while (v == n)
            {
                v = rand.Next(0, 10);
            }

            return v;
        }
    }
}
