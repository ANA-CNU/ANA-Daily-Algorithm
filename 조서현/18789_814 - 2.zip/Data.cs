﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppTest
{
    public class Data
    {
        public int[,] Table;
        public int Score;
        public int Tries;

        public Data()
        {
            Table = new int[8, 14];
        }

        public Data(int[,] Table)
        {
            this.Table = Table;
        }

        public Data(Data other) : this((int[,])other.Table.Clone())
        {
            this.Score = other.Score;
        }

        public Data DeepCopy()
        {
            var res = new Data(this);
            return res;
        }

        public static Data CreateRandom()
        {
            var res = new Data();
            var rand = new Random();
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 14; j++)
                {
                    res.Table[i, j] = rand.Next(0, 10);
                }
            }

            res.Score = Program.ScoreMetric(res);
            return res;
        }

        public static Data FromFile(string file)
        {
            var lines = File.ReadAllLines(file);
            var res = new Data();
            for (int i = 0; i < 8; i++)
            {
                var tokens = lines[i].Select(x => int.Parse(x.ToString())).ToArray();
                for (int j = 0; j < 14; j++)
                {
                    res.Table[i, j] = tokens[j];
                }
            }

            res.Score = Program.ScoreMetric(res);
            return res;
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            for (int i = 0; i < 8; i++)
            {
                for (int j = 0; j < 14; j++)
                {
                    sb.Append(Table[i, j]);
                }

                sb.AppendLine();
            }
            return sb.ToString();
        }
    }
}
