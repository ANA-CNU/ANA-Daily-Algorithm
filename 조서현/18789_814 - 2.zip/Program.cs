﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleAppTest;

internal class Program
{
    // CONFIG START
    public const int DatabaseSize = 60; // 데이터베이스의 크기
    public const int Threads = 16; // 병렬처리할 쓰레드의 크기 (CPU의 코어에 맞추는 걸 추천)
    public const int SaveFrequency = 100000; // 데이터베이스를 디스크에 저장하는 빈도 (ScoreMetric1일 경우 100000, ScoreMetric2일 경우 30000 추천)
    public const int CurTriesFrequency = 100000; // 현재 몇 트 째인지 출력하는 빈도
    public const int PermutationThreshold = 10000; // 순열화를 할 누적 시도 횟수
    public const bool ExitWhenOver8140 = false; // 8140점을 넘기면 종료

    // ScoreMetric1: 문제에서 요구하는 점수
    // ScoreMetric2: 1~12000까지 읽을 수 있는 수의 개수
    public static readonly Func<Data, int> ScoreMetric = Heuristic.ScoreMetric1; // or Heuristic.ScoreMetric2
    // CONFIG END

    public static int Tries;
    public static int LastBestTry;
    private static void Main(string[] args)
    {
        var db = new Database(DatabaseSize);
        
        var tasks = new Task[Threads];
        bool end = false;
        for (int i = 0; i < Threads; i++)
        {
            tasks[i] = Task.Factory.StartNew(() =>
            {
                while (!end)
                {
                    Tries++;
                    var rand = new Random();
                    if (Tries % SaveFrequency == 0)
                    {
                        WriteLine("state saved!");
                        lock (db.lockObj)
                            db.SaveState();
                    }
                    if (Tries % CurTriesFrequency == 0)
                    {
                        WriteLine($"cur tries: {Tries}");
                    }
                    Data prev, cur;
                    lock (db.lockObj)
                        prev = db.PickRandom();

                    if (prev.Tries > PermutationThreshold && rand.NextDouble() < 0.1)
                    {
                        lock (db.lockObj)
                        {
                            if (db.db.Contains(prev))
                                db.db.Remove(prev);
                        }
                        cur = Heuristic.MutatePermutation(prev);
                        lock (db.lockObj)
                        {
                            if (cur.Score > db.UpperBound)
                            {
                                WriteLine($"new record by permutation: {cur.Score}\n{cur}\b, {prev.Score}->{cur.Score}, {prev.Tries}");
                                LastBestTry = Tries;
                            }
                            else if (prev.Score < cur.Score)
                            {
                                WriteLine($"updated score by permutation: {prev.Score}->{cur.Score}, {prev.Tries}");
                            }
                            else
                            {
                                WriteLine($"forced permutation: {prev.Score}->{cur.Score}, {prev.Tries}");
                            }
                            db.Offer(cur);
                        }

                        continue;
                    }

                    cur = Heuristic.Mutate(prev);
                    lock (db.lockObj)
                    {
                        if (ExitWhenOver8140 && cur.Score >= 8140)
                        {
                            end = true;
                            WriteLine($"FINALLY I SOLVED. {cur.Score}\nSUBMIT '{Path.Combine(Directory.GetCurrentDirectory(), "SUBMIT_ME.txt")}'");
                            File.WriteAllText("SUBMIT_ME.txt", cur.ToString());
                            return;
                        }
                        if (db.LowerBound <= cur.Score)
                        {
                            if (db.UpperBound < cur.Score)
                            {
                                WriteLine($"new record: {cur.Score}\n{cur}\b, {prev.Score}->{cur.Score}, {prev.Tries}");
                                LastBestTry = Tries;
                            }
                            else if (prev.Score < cur.Score)
                            {
                                WriteLine($"updated score: {prev.Score}->{cur.Score}, {prev.Tries}");
                            }

                            //if (prev.Score == cur.Score)
                            //    cur.Tries += prev.Tries;

                            db.Offer(cur);
                        }
                    }


                }
            }).ContinueWith((task => Console.WriteLine($"task.{task.Id} is done with {task.Exception?.Message ?? "no error"}")));
        }

        while (true)
        {
            while (consoleQueue.Count > 0)
                Console.WriteLine(consoleQueue.Dequeue());
            Thread.Sleep(1000);
        }
    }


    private static readonly Queue<string> consoleQueue = new();

    public static void WriteLine(string str)
    {
        lock (consoleQueue)
        {
            consoleQueue.Enqueue(str);
        }
    }
}
