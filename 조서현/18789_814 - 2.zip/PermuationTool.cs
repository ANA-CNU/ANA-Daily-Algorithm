﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleAppTest
{
    public static class PermuationTool
    {
        public static IEnumerable<T> TakeRandom<T>(this List<T> lst, int cnt)
        {
            var rand = new Random();
            //int offset = rand.Next(lst.Count - 1 - cnt);
            for (int i = 0; i < cnt; i++)
            {
                yield return lst[rand.Next(lst.Count)];
            }
        }
        public static List<int[]> GetPermutations(int[] numbers)
        {
            List<int[]> result = new List<int[]>();
            Permute(numbers, 0, result);
            return result;
        }

        static void Permute(int[] numbers, int start, List<int[]> result)
        {
            if (start == numbers.Length - 1)
            {
                result.Add((int[])numbers.Clone());
                return;
            }

            for (int i = start; i < numbers.Length; i++)
            {
                Swap(numbers, start, i);
                Permute(numbers, start + 1, result);
                Swap(numbers, start, i); // backtrack
            }
        }

        static void Swap(int[] numbers, int i, int j)
        {
            (numbers[i], numbers[j]) = (numbers[j], numbers[i]);
        }
    }
}
